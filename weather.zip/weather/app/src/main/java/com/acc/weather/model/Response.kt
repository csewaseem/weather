package com.acc.weather.model

sealed class Response<out R> {

    data class Success<out T>(val data: T) : Response<T>()
    data class Failure<out T>(val failure: WeatherError, val data: T? = null) : Response<T>()
    data class Error(val exception: Exception) : Response<Nothing>()

    override fun toString(): String {
        return when (this) {
            is Success<*> -> "Success[data=$data]"
            is Failure<*> -> "Failure[failure=$failure, data=$data]"
            is Error -> "Error[exception=$exception]"
        }
    }
}

/**
 * `true` if [Result] is of episodeType [Success] & holds non-null [Success.data].
 */
val Response<*>.succeeded
    get() = this is Response.Success && data != null
