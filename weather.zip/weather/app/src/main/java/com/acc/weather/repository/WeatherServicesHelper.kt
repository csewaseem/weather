package com.acc.weather.repository

import android.content.Context
import com.acc.weather.data.Constants
import com.acc.weather.data.RetrofitApiHelper

class WeatherServicesHelper(val context: Context) :
    RetrofitApiHelper<WeatherRepositoryService>() {

    override fun createTransactRetrofit(): WeatherRepositoryService =
        createRetrofit(Constants.BASE_URL).create(WeatherRepositoryService::class.java)
}