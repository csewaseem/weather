package com.acc.weather.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.acc.weather.R
import com.acc.weather.adapter.WeatherAdapter
import com.acc.weather.data.Event
import com.acc.weather.data.WeatherData
import com.acc.weather.data.WeatherList
import com.acc.weather.utils.WeatherUtils
import com.acc.weather.viewmodel.WeatherViewModel
import kotlinx.android.synthetic.main.header.*
import kotlinx.android.synthetic.main.weather_fragment.*
import org.koin.android.viewmodel.ext.android.sharedViewModel
import com.acc.weather.model.Result

class WeatherFragment : Fragment() {

    private lateinit var mActivity: WeatherActivity
    private val viewModel: WeatherViewModel by sharedViewModel()
    lateinit var weatherItemAdapter: WeatherAdapter
    private lateinit var rootView: View
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
         rootView = inflater.inflate(R.layout.weather_fragment, container, false)
        return rootView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mActivity = activity as WeatherActivity

        setUpToolbar()
        getWeatherList()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.weatherDataEventTrigger.postValue(Event(Unit))
    }

    private fun getWeatherList() {
        showLoader()
        viewModel.weatherDataEventTriggerEvent.observe(mActivity, weatherDataObserver)
    }

    @SuppressLint("WrongConstant")
    private fun weatherAdapter(weatherList: List<WeatherList>?) {
        val linearLayoutManager = LinearLayoutManager(mActivity)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recycleWeather.setLayoutManager(linearLayoutManager)
        weatherItemAdapter = WeatherAdapter(mActivity, weatherList ?: listOf())
        weatherItemAdapter.setOnItemClickListener(object : WeatherAdapter.OnItemClickListener {
            override fun onClick(view: View, data: WeatherList) {
            }
        })
        recycleWeather.adapter = weatherItemAdapter
        weatherItemAdapter.notifyDataSetChanged()
    }

    private fun setUpToolbar() {
        mActivity?.setSupportActionBar(toolbar)
        mActivity?.supportActionBar?.title = getString(R.string.app_name)
        mActivity?.supportActionBar?.setDisplayHomeAsUpEnabled(true)
        mActivity?.supportActionBar?.setDisplayShowHomeEnabled(true)
        toolbar.setNavigationIcon(R.drawable.ic_close)
        toolbar.setNavigationOnClickListener {
            mActivity?.onBackPressed()
        }
    }

    val weatherDataObserver = Observer<Result<WeatherData>?>{
        if (it is Result.Loading) {

        } else {
            if (it is Result.Success) {
                    weatherAdapter(it?.data?.list)
                hideLoader()
            }
            if (it is Result.Error) {
                hideLoader()
                WeatherUtils.handleError(mActivity, it?.exception)
            }
            if (it is Result.Failure) {
                hideLoader()
            }
        }
    }

    private fun hideLoader() {
        progressBar?.visibility = View.GONE
    }

    private fun showLoader() {
        progressBar?.visibility = View.VISIBLE
    }

}