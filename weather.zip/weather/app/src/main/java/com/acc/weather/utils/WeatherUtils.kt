package com.acc.weather.utils

import android.content.Context
import android.util.Log
import com.acc.weather.R
import com.acc.weather.data.Constants.CONNECTION_TIMEOUT
import java.text.SimpleDateFormat
import java.util.*

object WeatherUtils {

    fun formatSystemDate(systemDate: Long, format: String): String {
        return try {
            val formatter = SimpleDateFormat(format, Locale.ENGLISH)
            val calendar = Calendar.getInstance()
            calendar.timeInMillis = systemDate
            formatter.format(calendar.time)
        } catch (e: Exception) {
            e.message?.let { Log.e("Format date", it) }
            ""
        }
    }

    fun handleError(context: Context, articleError: Exception, callback: (() -> Unit)? = null) {
        val isTimeOut = articleError.message == CONNECTION_TIMEOUT
        var title = context.getString(R.string.error)
        var message = articleError.message ?: ""
        if (isTimeOut) {
            title = context.getString(R.string.subheadConnectionError)
            message = context.getString(R.string.bodycopyConnectionError)
            WeatherDialog.showConfirmDialog(context, title, message)
        } else {
            if (callback != null) {
                callback()
            } else {
                WeatherDialog.showConfirmDialog(
                    context,
                    context.getString(R.string.error),
                    context.getString(R.string.generic_error_message)
                )
            }
        }

    }
}