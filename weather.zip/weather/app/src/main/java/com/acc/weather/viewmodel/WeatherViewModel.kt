package com.acc.weather.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.acc.weather.data.Event
import com.acc.weather.data.WeatherData
import com.acc.weather.usecase.WeatherViewModelUsecase
import org.koin.core.KoinComponent
import org.koin.core.inject
import com.acc.weather.model.Result


class WeatherViewModel(application: Application) : ViewModel(), KoinComponent {

    private val weatherViewModelUsecase: WeatherViewModelUsecase by inject()

    internal val weatherDataEventTrigger = MutableLiveData<Event<Unit>>()

    val weatherDataEventTriggerEvent: LiveData<Result<WeatherData>> =
        Transformations.switchMap(weatherDataEventTrigger) {
            it.getContentIfNotHandled()?.let {
                weatherViewModelUsecase.execute()
            }
        }
}