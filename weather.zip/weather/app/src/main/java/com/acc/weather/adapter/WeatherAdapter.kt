package com.acc.weather.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.acc.weather.R
import com.acc.weather.data.WeatherList


class WeatherAdapter(
    var context: Context,
    var weatherList: List<WeatherList>
) : RecyclerView.Adapter<WeatherAdapter.ViewHolder>() {

    lateinit var listener: OnItemClickListener
    override fun onCreateViewHolder(
            viewGroup: ViewGroup,
            viewType: Int
    ): ViewHolder {
        val inflater = LayoutInflater.from(viewGroup.context)
        val view = inflater.inflate(R.layout.cardview, viewGroup, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val weatherList = weatherList[position]
        weatherList.let {
            holder.degree.text = weatherList?.main?.temp?.toString()
            weatherList?.weather.forEach {
                holder.weather.text = it.description
            }
            holder.dateTime.text = weatherList?.dt_txt

            holder.cardLayout.setOnClickListener {
                listener.onClick(it, weatherList)
            }
        }
    }

    override fun getItemCount(): Int {
            return weatherList.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var title: TextView = itemView.findViewById(R.id.currentTemp) as TextView
        var weather: TextView = itemView.findViewById(R.id.weather) as TextView
        var dateTime: TextView = itemView.findViewById(R.id.dateTime) as TextView
        var degree: TextView = itemView.findViewById(R.id.degree) as TextView
        var cardLayout: CardView =
            itemView.findViewById(R.id.card) as CardView
    }

    interface OnItemClickListener {
        fun onClick(view: View, data: WeatherList)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener
    }

}