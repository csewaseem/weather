package com.acc.weather.utils

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.InsetDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import com.acc.weather.R
import kotlinx.android.synthetic.main.confirm_dialog.view.*

object WeatherDialog {

    fun showConfirmDialog(
        context: Context, title: String, message: String? = "", confirmText: String = "Ok", cbOk: () -> Unit = {}
    ) {
        val mDialogView = LayoutInflater.from(context).inflate(R.layout.confirm_dialog, null)
        if (title.isNullOrEmpty()) {
            mDialogView.header.visibility = View.GONE
        } else {
            mDialogView.header.text = title
        }
        mDialogView.positiveButton.text = confirmText

        mDialogView.message.text = message

        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(mDialogView)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val back = ColorDrawable(Color.TRANSPARENT)
        val inset = InsetDrawable(back, 60)
        dialog.window?.setBackgroundDrawable(inset)
        dialog.setCancelable(false)
        dialog.show()

        mDialogView.positiveButton.setOnClickListener {
            dialog.dismiss()
            cbOk()
        }

    }
}
