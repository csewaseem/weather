package com.acc.weather.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import com.acc.weather.R
import kotlinx.android.synthetic.main.activity_weather.*

class WeatherActivity : AppCompatActivity() {

    private lateinit var mNavHostFragment: NavHostFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather)
        mNavHostFragment = supportFragmentManager.findFragmentById(R.id.weather_navHostFragment) as NavHostFragment
    }

    override fun onSupportNavigateUp() =
        NavHostFragment.findNavController(weather_navHostFragment).navigateUp()
}