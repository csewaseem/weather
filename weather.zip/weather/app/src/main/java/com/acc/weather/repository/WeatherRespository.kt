package com.acc.weather.repository

import com.acc.weather.data.WeatherData
import com.acc.weather.model.Response
import retrofit2.Call
import retrofit2.await

class WeatherRespository constructor(private val weatherRepositoryService: WeatherRepositoryService) {

    suspend fun getWeather(): Response<WeatherData> {
        return try {
            val result = getWeatherAPI().await()
            with(result) {
                Response.Success(this)
            }
        } catch (e: Exception) {
            Response.Error(e)
        }
    }

    private fun getWeatherAPI(): Call<WeatherData> {
        return weatherRepositoryService.getWeather()
    }

}
