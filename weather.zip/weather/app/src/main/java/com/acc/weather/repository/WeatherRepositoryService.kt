package com.acc.weather.repository

import com.acc.weather.data.WeatherData
import retrofit2.Call
import retrofit2.http.GET

interface WeatherRepositoryService {

    @GET("forecast?q=singapore&appid=75d70b113837c0e58bb7952bf5ec2289")
    fun getWeather(): Call<WeatherData>
}