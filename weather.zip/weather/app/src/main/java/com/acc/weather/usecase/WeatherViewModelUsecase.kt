package com.acc.weather.usecase

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.acc.weather.data.WeatherData
import com.acc.weather.model.Response
import com.acc.weather.model.Response.Error
import com.acc.weather.model.UseCaseWithOutParameter
import com.acc.weather.repository.WeatherRespository
import io.reactivex.functions.Cancellable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext
import com.acc.weather.model.Result


class WeatherViewModelUsecase(private val weatherRespository: WeatherRespository):
    UseCaseWithOutParameter<LiveData<Result<WeatherData>>>,
    Cancellable,
    CoroutineScope {

    private var job: Job? = null
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.IO

    override fun execute(): LiveData<Result<WeatherData>> {
        val result = MutableLiveData<Result<WeatherData>>()
        result.postValue(Result.Loading)
        job = launch {
            val toPost = when (val response =
                weatherRespository.getWeather()) {
                is Response.Success -> {
                    Result.Success(response.data)
                }
                is Response.Failure -> {
                    Result.Failure(response.failure)
                }
                is Error -> {
                    Result.Error(response.exception)
                }
            }
            result.postValue(toPost)
        }
        return result
    }

        override fun cancel() {
            job?.cancel()
        }
}