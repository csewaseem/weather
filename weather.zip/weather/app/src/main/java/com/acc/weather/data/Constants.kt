package com.acc.weather.data

object Constants {

    const val ERROR_MESSAGE = "We are unable to process your request. For assistance, call"

    const val BASE_URL: String = "https://api.openweathermap.org/data/2.5/"

    const val NETWORK_CALL_TIMEOUT = 60

    const val APP_ID = "75d70b113837c0e58bb7952bf5ec2289"

    const val CONNECTION_TIMEOUT = "We are unable to connect. You can check your connection or try again later."

}