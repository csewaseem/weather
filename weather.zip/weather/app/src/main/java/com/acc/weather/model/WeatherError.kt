package com.acc.weather.model

import com.acc.weather.data.Constants.ERROR_MESSAGE


data class WeatherError(val errorMessage: String? = ERROR_MESSAGE) {

    companion object {
        private fun getErrorMessage(errorMessage: String?): String? {
            return errorMessage
        }
    }

    var message: String? = ""
        get() = getErrorMessage(errorMessage)

}