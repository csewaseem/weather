package com.acc.weather.di

import android.content.Context
import com.acc.weather.repository.WeatherRepositoryService
import com.acc.weather.repository.WeatherRespository
import com.acc.weather.repository.WeatherServicesHelper
import com.acc.weather.usecase.WeatherViewModelUsecase
import com.acc.weather.viewmodel.WeatherViewModel
import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module


val weatherApp = module {
    single { provideWeatherServicesAPI(androidContext()) }
    single { WeatherRespository(get()) }
//    single { ArticleDetailsRespository(get()) }
    single { WeatherViewModelUsecase(get()) }
//    single { ArticleDetailViewModelUsecase(get()) }
    viewModel { WeatherViewModel(androidApplication()) }
//    viewModel { ArticleDetailsViewModel(androidApplication()) }
}

fun provideWeatherServicesAPI(context: Context): WeatherRepositoryService {

    return WeatherServicesHelper(context).createTransactRetrofit()
}